var pos = 0, test, test_status, question, choice, choices, choiceA, choiceB, choiceC, correct=0, name = 0; 
//setting variables
		
var questions=[
    ['Who was the first female President of Ireland?', "Mary Robinson", "Mary McAleese", "Miriam O'Callaghan", "A"],
    ['What is the capital of France?', "Berlin", "Paris", "Rome", "B"],
    ['How much is in a bakers dozen?', 100, 80, 13, "C"],
    ['What is the largest county in Ireland?', "Galway", "Cork", "Donegal", "B"],
    ['What is 5 multiplied by 5?', 10, 50, 25, "C"],
    ['Who is the taoiseach of Ireland?', "Enda Kenny", "Richard Bruton", "Michael Martin", "A"],
    ['The longest river in Ireland is the ', "Shannon", "Liffey", "Lee", "A"],
    ['The Book of Kells was written in what language?', "Irish", "Latin", "English", "B"],
    ['In what year was the Battle of Clontarf?', 1213, 1014, 1618, "B"],
    ['Who is the President of the USA?', "Barack Obama", "Donald Trump", "Ronald Regan", "B"],
	['What county is known as the Kingdom?', "Limerick", "Mayo", "Kerry", "C"],
	['What is the smallest county in Ireland?', "Louth", "Roscommon", "Westmeath", "A"],
	['How many provinces are there in Ireland?', 5, 4, 6, "B"],
	['In which city is the Irish soap "Fair City" set?', "Dublin", "Cavan", "Wexford", "A"],
	['To make an Irish Coffee, what alcohol ingredient would you use?', "Whiskey", "Vodka", "Baileys", "C"],
	['In which town in County Roscommon is the Irish Famine Museum?', "Strokestown", "Castlerea", "Roscommon", "A"],
	['Where is the All Ireland Football Final held every year?', "Pairc Uí Chaoimh", "Croke Park", "Semple Stadium", "B"],
	['Who is the patron saint of Ireland?', "St Patrick", "St Brendan", "St Kevin", "A"],
	['Which Irish poet wrote the famous poem "Digging"?', "Brendan Behan", "John Montague", "Seamus Hardy", "C"],
	['Which Irish city is also known as "city of the tribes"?', "Waterford", "Galway", "Dublin", "B"],
]; 


function renderQuestion()
	{
		test = _("test");
		if(pos >= questions.length) // If position is greater than or equal to the number of questions
	{
	test.innerHTML = "<h2>You got "+correct+" of "+questions.length+" questions correct(" +percent() + "%)</h2>";// Print # correct out of 20
	("test_status").innerHTML += " Thank you for completing the quiz";//Print "Thank You..."
		pos=0;
		correct=0;
		return false;
	}

	var bar=document.getElementById("progressBar");//Progress bar value

	_("test_status").innerHTML = "Question" + (pos+1)+ " of "+questions.length;
	//Print questions and increment by one each iteration

	bar.value = (pos+1)//Progress bar increments as we go through questions, starts at 1

	question = questions[pos][0];
	choiceA = questions[pos][1];
	choiceB = questions[pos][2];
	choiceC = questions[pos][3];
	test.innerHTML = "<h3>"+question+"</h3>";
	test.innerHTML += "<input type='radio' name='choices' value='A' checked> "+choiceA+"<br>"; //Radio button
	test.innerHTML += "<input type='radio' name='choices' value='B'> "+choiceB+"<br>";//Radio button
	test.innerHTML += "<input type='radio' name='choices' value='C'> "+choiceC+"<br><br>";//Radio button
	test.innerHTML += "<button onclick='checkAnswer()'>Submit Answer</button>";//on clicking submit button, it checks your answers.
} 

function checkAnswer()
{
	choices = document.getElementsByName("choices"); // Creates an array
	for(var i=0; i<choices.length; i++)	// variable i=0, when i is less than the length of the choices, increment it by 1.
	{
		if(choices[i].checked) // if a choice is checked
		{
			choice = choices[i].value; //Take the value of the choice and put it into choice
		}
	}
	if(choice = questions[pos][4]) // If the value of choices is equal to position 4
	{	
		alert('Correct! You got it!'); // Alert correct
		correct++;//Increment your correct answer by 1
	}
	else//or else
	{
		alert('Wrong. Keep going! The correct answer is ' + questions[pos][4]);
	}
		pos++; // Increment psotition by 1 ie go on the next question
		renderQuestion(); // go to render question again
	} 
		function _(x)
	{ 
    return document.getElementById(x);
	} 
//Setting underscore equal to document.getElementById (handy shortcut)
function percent()
{
    var perc = Math.round((correct/questions.length)*100);
    return perc;//gets percentage and returns to form
}

//Insert Javascript functions renderQuestion() & checkAnswer() here

//Call the question with an event handler
window.addEventListener("load", renderQuestion, false);

